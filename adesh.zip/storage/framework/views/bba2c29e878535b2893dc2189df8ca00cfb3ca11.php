<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

<Style>
    body{
        background-color: #aaa;
        background-image: url(<?php echo e(asset('users/img/bg-login.svg')); ?>);
        background-position: center;
        background-repeat : no-repeat;
        background-size:cover;
    }

    .card{
        background-color: #ffffff99;
        backdrop-filter: blur(10px);
    }
    .btn-primary{
        background: #683f95 !important;
        border:#683f95 !important;
    }   
    .text-warning{

    }
</Style>
</head>

<body>
    <div class="container">

        <div class="row  mt-5 ">
            <div class="col-lg-4 mx-auto bg_image px-2 p-lg-5  card">
                <?php if(Session::has('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                <?php endif; ?>
                <?php if(Session::has('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <div class="mx-auto text-center">
                    <img src="<?php echo e(asset('users/img/logo.png')); ?>" class='mx-auto text-center py-3 w-75' alt="">
                </div>

                <form method="POST" action="<?php echo e(route('user.register')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="spid" class="form-label">Sponser Id</label>
                        <input type="text" class="form-control " name="spid" id="spid" onchange="checkSp(this.value)"
                            placeholder="Enter Sponser Id">
                        <div class="text-danger err"></div>
                        <div class="text-success succ"></div>
                            <?php $__errorArgs = ['spid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" class="form-control " name="name" id="name"
                            placeholder="Enter Name" required>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control " name="email" id="email"
                            placeholder="Enter Email" required>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label for="phone" class="form-label">Phone</label>
                        <input type="number" class="form-control " name="phone" id="phone"
                            placeholder="Enter Phone" required>
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control " name="password" id="password"
                            placeholder="Enter Password" required>
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label"> Confirm Password</label>
                        <input type="password" class="form-control " name="password_confirmation" id="password-confirm"
                            placeholder="Enter Password" required>
                            <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class=" mx-auto text-center py-4">
                        <button type='submit' class="btn btn-primary w-75">Register</button>
                    </div>
                    <div class="text-center  ">

                        
                        <a href="<?php echo e(route('login')); ?>" class='text-success'>Already have an account? </a>
                    </div>
                </form>
            </div>

        </div>
    </div>
    </form>

    <script>
        function checkSp(id){
           $.ajax({
            url:"<?php echo e(route('checkSp')); ?>",
            data:{
                id:id
            },
            success:function(data){
                // console.log(data);
                $(".err").text('');
                $(".succ").text(data.user_name);
            },
            error:function(err){
                // console.log(err.responseJSON.error);
                $(".succ").text('');
                $(".err").text(err.responseJSON.error);
            }
           });
        }
    </script>
</body>

</html>
<?php /**PATH /Users/admin/Desktop/projects/adesh/resources/views/auth/register.blade.php ENDPATH**/ ?>